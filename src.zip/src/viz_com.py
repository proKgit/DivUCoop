import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import CompressedImage
import numpy as np
class CompressedImageSubscriber(Node):
    def __init__(self):
        super().__init__('compressed_image_subscriber')
        self.image_subscriber = self.create_subscription(CompressedImage, 'CamFront', self.image_callback,1)
    
    def image_callback(self, msg):
        print(type(msg.data))
        np_arr = np.frombuffer(msg.data, np.uint8)
        print(np_arr.size)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        cv2.imshow('Image', img)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = CompressedImageSubscriber()
    rclpy.spin(image_subscriber)
    

if __name__ == '__main__':
        main()