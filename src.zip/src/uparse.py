from asyncio import constants
from math import cos,sin
import h5py
import numpy as np
import open3d as o3d
import cv2
import csv
import numpy as np
import pcl.pcl_visualization
import cv2



FILE="/home/changhe/DivUCoop/data/R05D02_RC16/#R05D02_RC16_0530_ChengDu_2023-05-30_19-16-11_TDA4DDS.mf4_CDDS.sdf"

DSTPATH = "/home/changhe/DivUCoop/parsed/"

MOUNT_X=0
MOUNT_Y=0
CLU_STATE_GATE=0.8

ORINENTATION=1


def hdftimebase2ns(hdft):
    return int(hdft*1e4)

def writelist2txt(dstfilename,lst):
    with open(dstfilename, 'w') as file:
        line = ' '.join(str(item) for item in lst)
        file.write(line)

def parseSingeVdy(d,t):
    lst = d.tolist()
    fn =DSTPATH+"vdy/"+str(t)+".vdytxt"
    writelist2txt(fn,lst)
    
def parsevdy(vdydata,vdytime):
    for i in range(0,len(vdydata)):
        vd=vdydata[i][0]
        vt=hdftimebase2ns(vdytime[i][0])
        parseSingeVdy(vd,vt)


def parseSingeFreespace(fsd,fst):
    lst=[fsd[0],fsd[1]]
    ctrs=fsd[2]
    for pt in ctrs:
        for attr in pt:
            lst.append(attr)
    lst.extend([fsd[3],fsd[4]])
    fn =DSTPATH+"fs/"+str(fst)+".fstxt"
    writelist2txt(fn,lst)

def parsefreespace(fsdata,fstime):
    for i in range(0,len(fsdata)):
        fd=fsdata[i][0]
        ft=hdftimebase2ns(fstime[i][0])
        parseSingeFreespace(fd,ft)


def parseSingelObject(od,ot):
    lst = []
    for obj in od:
        for attr in obj:
            lst.append(attr)
    fn =DSTPATH+"obj/"+str(ot)+".objtxt"
    writelist2txt(fn,lst)


def parseobjlist(objdata,objt):
    for i in range(0,len(objdata)):
        od=objdata[i][0]
        ot=hdftimebase2ns(objt[i][0])
        parseSingelObject(od,ot)



def parseSinglePs(pd,pt):
    lst=[]
    for p in pd:
        for j in range(0,len(p)-1):
            lst.append(p[j])
        for num in p[-1]:
            lst.append(num)
    fn =DSTPATH+"ps/"+str(pt)+".pstxt"
    writelist2txt(fn,lst)

def parsepslist(psdata,pst):
    for i in range(0,len(psdata)):
        pd=psdata[i][0]
        pt=hdftimebase2ns(pst[i][0])
        parseSinglePs(pd,pt)

def parseSingleUss(ud,ut):
    lst=[]
    for num in ud:
        lst.append(num)
    fn =DSTPATH+"uss/"+str(ut)+".usstxt"
    writelist2txt(fn,lst)


def parseuss(ussdata,usst):
    for i in range(0,len(ussdata)):
        ud=ussdata[i][0]
        ut=hdftimebase2ns(usst[i][0])
        parseSingleUss(ud,ut)



f=h5py.File(FILE,'r')

print("VDY START")
vdy = f['Logdata']['Vehicle']['vehicle']['Data']
vdytime=f['Logdata']['Vehicle']['vehicle']['Time']
parsevdy(vdy,vdytime)

print("FS START")
freespace = f['Logdata']['SVS']['Freespace']['FSPP_CameraFreespaceType_t_Tag']['Data']
freespacetime = f['Logdata']['SVS']['Freespace']['FSPP_CameraFreespaceType_t_Tag']['Time']
parsefreespace(freespace,freespacetime)

print("OBJ START")
objlist = f['Logdata']['SVS']['Objs']['FSPP_CameraObjInput_t_Tag']['Data']['Obj']
objlisttime = f['Logdata']['SVS']['Objs']['FSPP_CameraObjInput_t_Tag']['Time']
parseobjlist(objlist,objlisttime)

print("PS START")
pslist = f['Logdata']['SVS']['ParkingSlot']['FSPP_CameraParkingSlotSet_t_Tag']['Data']['Slot_s']
pslisttime = f['Logdata']['SVS']['ParkingSlot']['FSPP_CameraParkingSlotSet_t_Tag']['Time']
parsepslist(pslist,pslisttime)

print("USS START")
usmeas = f['Logdata']['USS']['MinDistance']['FSPP_MinDistanceInput_t_Tag']['Data']['MinDistance']
usst = f['Logdata']['USS']['MinDistance']['FSPP_MinDistanceInput_t_Tag']['Time']
parseuss(usmeas,usst)



