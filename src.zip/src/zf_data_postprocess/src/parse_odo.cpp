#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <zf_data_postprocess/parse_odo.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <zf_data_postprocess/frgen_type.hpp>
using std::placeholders::_1;
using namespace std;

string ododstpath="/home/changhe/rosbag2_data_postprocessing/odo_bin/";
string odobag="/media/changhe/Data/newJTAROUND/ins_rosbag2_2023_02_28-13_44_27";
string odotopic="/Odo";


int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllOdoFile(filemap,"/home/changhe/rosbag2_data_postprocessing/odo_bin/");

    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"odobag","sqlite3"};
    writer.open(storage_options);
    add_topic(writer,"/Odom","nav_msgs/msg/Odometry");

    FrgenOdom_t o;

  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::ifstream in(filemap[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&o), sizeof(o));
    in.close();

    nav_msgs::msg::Odometry omsg;
    omsg.header.stamp=rclcpp::Time(o.ts);
    omsg.child_frame_id="base_link";
    omsg.header.frame_id="map";
    omsg.pose.pose.position.x = o.x;
    omsg.pose.pose.position.y = o.y;
    omsg.pose.pose.position.z = o.z;

    omsg.pose.pose.orientation.w = o.qw;
    omsg.pose.pose.orientation.x = o.qx;
    omsg.pose.pose.orientation.y = o.qy;
    omsg.pose.pose.orientation.z = o.qz;

    omsg.twist.twist.linear.x=o.vx;
    omsg.twist.twist.linear.y=o.vy;
    omsg.twist.twist.linear.z=o.vz;

    for(int i=0;i<9;i++)
    {
      omsg.pose.covariance[i]=o.variance[i];
    }

    writer.write(omsg, "/Odom", omsg.header.stamp);
  }



// {
//     rosbag2_cpp::Writer writer;
//     rosbag2_storage::StorageOptions storage_options{"mybag","sqlite3"};
//     // storage_options.storage_id = "sqlite3";
//     // storage_options.uri = "/home/changhe/rosbag2_data_postprocessing/my_bag";
//     writer.open(storage_options);
//     add_topic(writer,"/helloworld","std_msgs/msg/String");

//     for(int i=0;i<100;i++)
//     {
//     std_msgs::msg::String msg;
//     msg.data=to_string(i);
//     // now we already can write the msg directly!
//     writer.write(msg, "/helloworld", rclcpp::Clock().now());
//     }
// }


// OdoType_t od;

// rosbag2_cpp::Reader reader;
// reader.open(odobag);
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();
//       if(bag_message->topic_name ==  odotopic)

//       {
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
// nav_msgs::msg::Odometry extracted_test_msg;
//     rclcpp::Serialization<nav_msgs::msg::Odometry> serialization;

//       serialization.deserialize_message(
//         &extracted_serialized_msg, &extracted_test_msg);

//         od.ts=rclcpp::Time(extracted_test_msg.header.stamp).nanoseconds();
//         od.x=extracted_test_msg.pose.pose.position.x;
//         od.y=extracted_test_msg.pose.pose.position.y;
//         od.z=extracted_test_msg.pose.pose.position.z;

//         od.qw=extracted_test_msg.pose.pose.orientation.w;
//         od.qx=extracted_test_msg.pose.pose.orientation.x;
//         od.qy=extracted_test_msg.pose.pose.orientation.y;
//         od.qz=extracted_test_msg.pose.pose.orientation.z;

//         od.vx=extracted_test_msg.twist.twist.linear.x;
//         od.vy=extracted_test_msg.twist.twist.linear.y;
//         od.vz=extracted_test_msg.twist.twist.linear.z;

//         for(int i=0;i<9;i++)
//         {
//           od.variance[i]=extracted_test_msg.pose.covariance[i];
//         }


//     std::ofstream out(ododstpath+std::to_string(od.ts)+".odo", std::ios::binary);
//     std::cout<<ododstpath+std::to_string(od.ts)+".odo"<<std::endl;
//     out.write(reinterpret_cast<char*>(&od), sizeof(od));
//     out.close();

//       }
//     }



  return 0;
}