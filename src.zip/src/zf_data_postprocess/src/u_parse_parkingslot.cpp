#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>
#include <zf_data_postprocess/parse_uparkingslot.hpp>


using std::placeholders::_1;
using namespace std;

string fstpath="/home/changhe/DivUCoop/parsed/ps/";

string fstopic="/USvsParkingSlot";

int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllUParkingSlotFile(filemap,"/home/changhe/DivUCoop/parsed/ps/");
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"ps","sqlite3"};

    writer.open(storage_options);
    add_topic(writer,"/USvsParkingSlot","project_msgs/msg/USvsParkingSlotList");


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);
    project_msgs::msg::USvsParkingSlotList list;
    list.header.stamp=rclcpp::Time(t);
    list.header.frame_id="base_link";

    list.pslist.resize(16);

    for(int i=0;i<16;i++)
    {
        auto& ps =  list.pslist[i];
        ps.timestamp = outvec[37*i + 0];
        ps.frameidx = outvec[37*i + 1];
        ps.p0x = outvec[37*i + 2];
        ps.p0y = outvec[37*i + 3];
        ps.p1x = outvec[37*i + 4];
        ps.p1y = outvec[37*i + 5];
        ps.p2x = outvec[37*i + 6];
        ps.p2y = outvec[37*i + 7];
        ps.p3x = outvec[37*i + 8];
        ps.p3y = outvec[37*i + 9];
        ps.width = outvec[37*i + 10];
        ps.depth = outvec[37*i + 11];
        ps.direction = outvec[37*i + 12];
        ps.slottype = outvec[37*i + 13];

        ps.slotstatus = outvec[37*i + 14];

        ps.slotdirectiontype = outvec[37*i + 15];
        ps.slotoccupied = outvec[37*i + 16];
        ps.quality = outvec[37*i + 17];
        ps.angle = outvec[37*i + 18];
        ps.lanewidth = outvec[37*i + 19];
        ps.trackingid= outvec[37*i + 20];

        ps.serialnumber.resize(16);

        ps.serialnumber[0] = outvec[37*i + 21];
        ps.serialnumber[1] = outvec[37*i + 22];
        ps.serialnumber[2] = outvec[37*i + 23];

        ps.serialnumber[3] = outvec[37*i + 24];
        ps.serialnumber[4] = outvec[37*i + 25];
        ps.serialnumber[5] = outvec[37*i + 26];
        ps.serialnumber[6] = outvec[37*i + 27];
        ps.serialnumber[7] = outvec[37*i + 28];
        ps.serialnumber[8] = outvec[37*i + 29];
        ps.serialnumber[9] = outvec[37*i + 30];
        ps.serialnumber[10] = outvec[37*i + 31];
        ps.serialnumber[11] = outvec[37*i + 32];
        ps.serialnumber[12] = outvec[37*i + 33];
        ps.serialnumber[13] = outvec[37*i + 34];
        ps.serialnumber[14] = outvec[37*i + 35];
        ps.serialnumber[15] = outvec[37*i + 36];
    }

    writer.write(list, "/USvsParkingSlot", list.header.stamp);
  }



  return 0;
}