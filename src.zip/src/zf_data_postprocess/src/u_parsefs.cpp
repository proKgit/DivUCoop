#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>
#include <zf_data_postprocess/parse_ufreespace.hpp>

using std::placeholders::_1;
using namespace std;

string fstpath="/home/changhe/DivUCoop/parsed/fs/";

string fstopic="/USvsFreespace";

int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllFreespaceFile(filemap,"/home/changhe/DivUCoop/parsed/fs/");
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"fsbag","sqlite3"};

    writer.open(storage_options);
    add_topic(writer,"/USvsFreespace","project_msgs/msg/USvsFreespace");


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);

project_msgs::msg::USvsFreespace fs;

fs.header.stamp=rclcpp::Time(t);
fs.header.frame_id="base_link";
fs.pointnum = outvec[0];
fs.closedcontour=outvec[1];
fs.vehiclepoints.resize(400);
for(int i=0;i<400;i++)
{
    fs.vehiclepoints[i].x = outvec[2+ i*9+0];
    fs.vehiclepoints[i].y = outvec[2+ i*9+1];
    fs.vehiclepoints[i].classtype = outvec[2+ i*9+2];
    fs.vehiclepoints[i].edge = outvec[2+ i*9+3];
    fs.vehiclepoints[i].id = outvec[2+ i*9+4];
    fs.vehiclepoints[i].vehiclex = outvec[2+ i*9+5];
    fs.vehiclepoints[i].vehicley = outvec[2+ i*9+6];
    fs.vehiclepoints[i].vehicleheading = outvec[2+ i*9+7];
    fs.vehiclepoints[i].fspointsource = outvec[2+ i*9+8];
}
fs.colortype=outvec[outvec.size() -2];
fs.classtype=outvec[outvec.size() -1];

std::cout<<fs.pointnum<<std::endl;

    writer.write(fs, "/USvsFreespace", fs.header.stamp);

  }



// rosbag2_cpp::Reader reader;
// reader.open(imubag);
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();
//       if(bag_message->topic_name == imutopic)
//       {
//       sensor_msgs::msg::Imu extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
//     rclcpp::Serialization<sensor_msgs::msg::Imu> serialization;
//         serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);
// SaveOneImuMsg(extracted_test_msg);
//       }
    // }



  return 0;
}