#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <zf_data_postprocess/parse_vdy.hpp>
#include <project_msgs/msg/vehicle_dynamics.hpp>
#include <zf_data_postprocess/frgen_type.hpp>
using std::placeholders::_1;
using namespace std;

int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllVdyFile(filemap,"/home/changhe/rosbag_parse_frgen/vdy_bin/");

    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"vdybag","sqlite3"};
    writer.open(storage_options);
    add_topic(writer,"/VehDyn","project_msgs/msg/VehicleDynamics");

  FrgenVehDyn_t v;


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;


    std::ifstream in(filemap[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&v), sizeof(v));
    in.close();

    project_msgs::msg::VehicleDynamics vmsg;
    vmsg.header.stamp=rclcpp::Time(v.ts);

    vmsg.frontwheelangle=v.frontwheelangle;
    vmsg.lataccel=v.lataccel;
    vmsg.longaccel=v.longaccel;
    vmsg.steeringwheelangle=v.steeringwheelangle;
    vmsg.steeringwheelanglespeed=v.steeringwheelangle;
    vmsg.timestamp=v.ts;
    vmsg.vehspeed=v.vehspeed;
    vmsg.wheelpulse_fl = v.wheelpulse_fl  ;
    vmsg.wheelpulse_fr = v.wheelpulse_fr  ;
    vmsg.wheelpulse_rl = v. wheelpulse_rl ;
    vmsg.wheelpulse_rr = v. wheelpulse_rr ;
    vmsg.wheelspeed_fl = v. wheelspeed_fl ;
    vmsg.wheelspeed_fr = v. wheelspeed_fr ;
    vmsg.wheelspeed_rl = v. wheelspeed_rl ;
    vmsg.wheelspeed_rr = v. wheelspeed_rr ;
    vmsg.yawrate = v. yawrate ;

    writer.write(vmsg, "/VehDyn", vmsg.header.stamp);
  }



// {
//     rosbag2_cpp::Writer writer;
//     rosbag2_storage::StorageOptions storage_options{"mybag","sqlite3"};
//     // storage_options.storage_id = "sqlite3";
//     // storage_options.uri = "/home/changhe/rosbag2_data_postprocessing/my_bag";
//     writer.open(storage_options);
//     add_topic(writer,"/helloworld","std_msgs/msg/String");

//     for(int i=0;i<100;i++)
//     {
//     std_msgs::msg::String msg;
//     msg.data=to_string(i);
//     // now we already can write the msg directly!
//     writer.write(msg, "/helloworld", rclcpp::Clock().now());
//     }
// }

// rosbag2_cpp::Reader reader;
// reader.open("mybag");
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();

//       topics.push_back(bag_message->topic_name);

//       std::cout<<bag_message->topic_name<<std::endl;

//       std_msgs::msg::String extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);

//   rclcpp::Serialization<std_msgs::msg::String> serialization;

//       serialization.deserialize_message(
//         &extracted_serialized_msg, &extracted_test_msg);
//     std::cout<<extracted_test_msg.data<<std::endl;
//     }
  return 0;
}