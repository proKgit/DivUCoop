#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>


using std::placeholders::_1;
using namespace std;


void add_topic(rosbag2_cpp::Writer& w,string name,string type,string serialization_frmt = "cdr")
{
    rosbag2_storage::TopicMetadata tm;
    tm.name = name;
    tm.type = type;
    tm.serialization_format = serialization_frmt;
    w.create_topic(tm);
}

void write_compressedimg(rosbag2_cpp::Writer& w,cv::Mat img_compressed,string topic,uint64_t ts)
{

}



int main(int argc, char * argv[])
{

{
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"mybag","sqlite3"};
    // storage_options.storage_id = "sqlite3";
    // storage_options.uri = "/home/changhe/rosbag2_data_postprocessing/my_bag";
    writer.open(storage_options);
    add_topic(writer,"/helloworld","std_msgs/msg/String");

    for(int i=0;i<100;i++)
    {
    std_msgs::msg::String msg;
    msg.data=to_string(i);
    // now we already can write the msg directly!
    writer.write(msg, "/helloworld", rclcpp::Clock().now());
    }

}

rosbag2_cpp::Reader reader;
reader.open("mybag");
std::vector<std::string> topics;
    while (reader.has_next()) {
      auto bag_message = reader.read_next();

      topics.push_back(bag_message->topic_name);

      std::cout<<bag_message->topic_name<<std::endl;

      std_msgs::msg::String extracted_test_msg;
      rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);

  rclcpp::Serialization<std_msgs::msg::String> serialization;

      serialization.deserialize_message(
        &extracted_serialized_msg, &extracted_test_msg);
    std::cout<<extracted_test_msg.data<<std::endl;
    }
  return 0;
}