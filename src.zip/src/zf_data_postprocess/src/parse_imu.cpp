#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <zf_data_postprocess/parse_compressed_image.hpp>
#include <zf_data_postprocess/parse_imu.hpp>
#include <project_msgs/msg/vehicle_dynamics.hpp>
#include <zf_data_postprocess/frgen_type.hpp>
using std::placeholders::_1;
using namespace std;

string imudstpath="/home/changhe/rosbag2_data_postprocessing/imu_bin/";
string imubag="/media/changhe/Data/newJTAROUND/ins_rosbag2_2023_02_28-13_44_27";
string imutopic="/Imu";
void SaveOneImuMsg(sensor_msgs::msg::Imu & msg)
{
    ImuType_t i;
    i.ts=rclcpp::Time(msg.header.stamp).nanoseconds();
    i.ax=msg.linear_acceleration.x;
    i.ay=msg.linear_acceleration.y;
    i.az=msg.linear_acceleration.z;

    i.wx=msg.angular_velocity.x;
    i.wy=msg.angular_velocity.y;
    i.wz=msg.angular_velocity.z;

    std::ofstream out(imudstpath+std::to_string(i.ts)+".imu", std::ios::binary);
    std::cout<<imudstpath+std::to_string(i.ts)+".imu"<<std::endl;
    out.write(reinterpret_cast<char*>(&i), sizeof(i));
    out.close();
}


int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllImuFile(filemap,"/home/changhe/rosbag2_data_postprocessing/imu_bin/");

    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"imubag","sqlite3"};
    writer.open(storage_options);
    add_topic(writer,"/Imu","sensor_msgs/msg/Imu");

  ImuType_t v;


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::ifstream in(filemap[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&v), sizeof(v));
    in.close();

    sensor_msgs::msg::Imu imsg;
    imsg.header.stamp=rclcpp::Time(v.ts);
    imsg.header.frame_id="imu";
    imsg.linear_acceleration.x=v.ax;
    imsg.linear_acceleration.y=v.ay;
    imsg.linear_acceleration.z=v.az;

    imsg.angular_velocity.x=v.wx;
    imsg.angular_velocity.y=v.wy;
    imsg.angular_velocity.z=v.wz;

    writer.write(imsg, "/Imu", imsg.header.stamp);
  }



// rosbag2_cpp::Reader reader;
// reader.open(imubag);
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();
//       if(bag_message->topic_name == imutopic)
//       {
//       sensor_msgs::msg::Imu extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
//     rclcpp::Serialization<sensor_msgs::msg::Imu> serialization;
//         serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);
// SaveOneImuMsg(extracted_test_msg);
//       }
    // }



  return 0;
}