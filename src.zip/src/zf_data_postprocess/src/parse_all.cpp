#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <sensor_msgs/msg/compressed_image.hpp>

#include <fstream>
#include <vector>

#include <zf_data_postprocess/parse_compressed_image.hpp>
#include <zf_data_postprocess/parse_frgen_ros1.hpp>
#include <zf_data_postprocess/parse_odo.hpp>
#include <zf_data_postprocess/parse_pcd.hpp>
#include <zf_data_postprocess/parse_vdy.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include "sensor_msgs/msg/image.hpp"
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <project_msgs/msg/vehicle_dynamics.hpp>
#include <zf_data_postprocess/parse_imu.hpp>
using namespace std;

string srcBasePath="/home/changhe/rosbag_parse_frgen/";


string dstBagPath = "/media/changhe/Data/parsedbag";

long get_dir_size(const char *dir) {
    long size = 0;
    DIR *dp;
    struct dirent *ep;
    dp = opendir(dir);
    if(dp != NULL) {
        while(ep = readdir(dp)){
            if(strcmp(ep->d_name, ".") && strcmp(ep->d_name, "..")) {
                struct stat st;
                char path[1024];
                sprintf(path, "%s/%s", dir, ep->d_name);
                stat(path, &st);
                size += st.st_size;
            }
        }
        closedir(dp);
    }
    return size;
}

int main(int argc, char * argv[])
{

  std::vector<std::pair<std::string,uint64_t>> ordered_msg;

//   std::vector<std::pair<std::string,uint64_t>> filemap_img;
  getAllOdoFile(ordered_msg,srcBasePath+"odo_bin/");

//   std::vector<std::pair<std::string,uint64_t>> filemap_pcd;
  getAllPcdFile(ordered_msg,srcBasePath+"128/");


//   std::vector<std::pair<std::string,uint64_t>> filemap_vdy;
  getAllVdyFile(ordered_msg,srcBasePath+"vdy_bin/");

  
//   std::vector<std::pair<std::string,uint64_t>> filemap_rad;
  getAllFrgenFile(ordered_msg,srcBasePath+"frgen_bin/");

    // std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllBinFile(ordered_msg,srcBasePath+"img_bin/");

  getAllImuFile(ordered_msg,srcBasePath+"imu_bin/");

  std::sort(ordered_msg.begin(), ordered_msg.end(), [](const std::pair<string, uint64_t>& a, const std::pair<string, uint64_t>& b) {
    return a.second < b.second;
});




int allmsg=ordered_msg.size();
int bagcounter=0;
string currentbagpath=dstBagPath+"_"+to_string(bagcounter);






std::shared_ptr<rosbag2_cpp::Writer> writer(new rosbag2_cpp::Writer());

// rosbag2_cpp::Writer *writer;
rosbag2_storage::StorageOptions storage_options{currentbagpath,"sqlite3"};
writer->open(storage_options);
add_topic(*writer,"/CamFront","sensor_msgs/msg/CompressedImage");
add_topic(*writer,"/Odom","nav_msgs/msg/Odometry");
add_topic(*writer,"/Pointcloud","sensor_msgs/msg/PointCloud2");
add_topic(*writer,"/VehDyn","project_msgs/msg/VehicleDynamics");
add_topic(*writer,"/Frgen","project_msgs/msg/RadarScanExtended");
add_topic(*writer,"/Imu","sensor_msgs/msg/Imu");



for(int i=0;i<ordered_msg.size();i++)
{
  if(i % 1000 == 0)
  {
    auto si=get_dir_size(currentbagpath.c_str());
    std::cout<<"Current size is "<<si<<std::endl;
  }

    if(ordered_msg[i].first.find(".imu")!=std::string::npos)
    {
      ImuType_t v;
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;

    std::ifstream in(ordered_msg[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&v), sizeof(v));
    in.close();

    sensor_msgs::msg::Imu imsg;
    imsg.header.stamp=rclcpp::Time(v.ts);
    imsg.header.frame_id="imu";
    imsg.linear_acceleration.x=v.ax;
    imsg.linear_acceleration.y=v.ay;
    imsg.linear_acceleration.z=v.az;

    imsg.angular_velocity.x=v.wx;
    imsg.angular_velocity.y=v.wy;
    imsg.angular_velocity.z=v.wz;

    writer->write(imsg, "/Imu", imsg.header.stamp);
    }


    if(ordered_msg[i].first.find(".bin")!=std::string::npos)
    {
      auto f=ordered_msg[i].first;
      auto t=ordered_msg[i].second;
      writeOneCompressedImg(*writer,f,t,"/CamFront");
    }


    if(ordered_msg[i].first.find(".frgen")!=std::string::npos)
    {

  FrgenDetectionList_t in_list;
    project_msgs::msg::RadarScanExtended scan;
    std::ifstream in(ordered_msg[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&in_list), sizeof(in_list));
    in.close();

    scan.header.frame_id="Frgen";
    scan.header.stamp=rclcpp::Time(in_list.ts);
    scan.targets.resize(in_list.numofdetection);

    for(int i=0;i<scan.targets.size();i++)
    {
      scan.targets[i].azimuth=in_list.list[i].azimuth;
      scan.targets[i].detectionconfidence  =  in_list.list[i].detectionconfidence;
      scan.targets[i].elevation  =  in_list.list[i].elevation;
      scan.targets[i].mean_square_error_azimuth  =  in_list.list[i].mean_square_error_azimuth;
      scan.targets[i].mean_square_error_elevation  =  in_list.list[i].mean_square_error_elevation;
      scan.targets[i].mean_square_error_range  =  in_list.list[i].mean_square_error_range;
      scan.targets[i].mean_square_error_subarray2nd_best  =  in_list.list[i].mean_square_error_subarray2nd_best;
      scan.targets[i].mean_square_error_subarray  =  in_list.list[i].mean_square_error_subarray;
      scan.targets[i].mean_square_error_velocity  =  in_list.list[i].mean_square_error_velocity;
      scan.targets[i].power  =  in_list.list[i].power;
      scan.targets[i].range  =  in_list.list[i].range;
      scan.targets[i].rcs  =  in_list.list[i].rcs;
      scan.targets[i].snr  =  in_list.list[i].snr;
      scan.targets[i].std_dev_azimuthangle  =  in_list.list[i].std_dev_azimuthAngle;
      scan.targets[i] .std_dev_elevationangle =  in_list.list[i].std_dev_elevationAngle;
      scan.targets[i].std_dev_range  =  in_list.list[i].std_dev_range;
      scan.targets[i] .std_dev_rcs =  in_list.list[i].std_dev_rcs;
      scan.targets[i].std_dev_velocity  =  in_list.list[i].std_dev_velocity;
      scan.targets[i].velocity  =  in_list.list[i].velocity;
    }
    scan.umabiguos_int_azimuth=in_list.umabiguos_int_azimuth;
    scan.umabiguos_int_elevation=in_list.umabiguos_int_elevation;
    scan.umabiguos_int_range=in_list.umabiguos_int_range;
    scan.umabiguos_int_velocity=in_list.umabiguos_int_velocity;

writer->write(scan, "/frgen", scan.header.stamp);  
    }

    if(ordered_msg[i].first.find(".odo")!=std::string::npos)
    {

  FrgenOdom_t o;
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;

    std::ifstream in(ordered_msg[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&o), sizeof(o));
    in.close();

    nav_msgs::msg::Odometry omsg;
    omsg.header.stamp=rclcpp::Time(o.ts);
    omsg.child_frame_id="base_link";
    omsg.header.frame_id="map";
    omsg.pose.pose.position.x = o.x;
    omsg.pose.pose.position.y = o.y;
    omsg.pose.pose.position.z = o.z;

    omsg.pose.pose.orientation.w = o.qw;
    omsg.pose.pose.orientation.x = o.qx;
    omsg.pose.pose.orientation.y = o.qy;
    omsg.pose.pose.orientation.z = o.qz;

    omsg.twist.twist.linear.x=o.vx;
    omsg.twist.twist.linear.y=o.vy;
    omsg.twist.twist.linear.z=o.vz;

    for(int i=0;i<9;i++)
    {
      omsg.pose.covariance[i]=o.variance[i];
    }

    writer->write(omsg, "/Odom", omsg.header.stamp);

    }


    if(ordered_msg[i].first.find(".pcd")!=std::string::npos)
    {
    auto f=ordered_msg[i].first;
    auto t=ordered_msg[i].second;
  writeOnePcd(*writer,f,t,"/Pointcloud","pandar128");   
    }

    if(ordered_msg[i].first.find(".vdy")!=std::string::npos)
    {
  FrgenVehDyn_t v;
   auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;


    std::ifstream in(ordered_msg[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&v), sizeof(v));
    in.close();

    project_msgs::msg::VehicleDynamics vmsg;
    vmsg.header.stamp=rclcpp::Time(v.ts);

    vmsg.frontwheelangle=v.frontwheelangle;
    vmsg.lataccel=v.lataccel;
    vmsg.longaccel=v.longaccel;
    vmsg.steeringwheelangle=v.steeringwheelangle;
    vmsg.steeringwheelanglespeed=v.steeringwheelangle;
    vmsg.timestamp=v.ts;
    vmsg.vehspeed=v.vehspeed;
    vmsg.wheelpulse_fl = v.wheelpulse_fl  ;
    vmsg.wheelpulse_fr = v.wheelpulse_fr  ;
    vmsg.wheelpulse_rl = v. wheelpulse_rl ;
    vmsg.wheelpulse_rr = v. wheelpulse_rr ;
    vmsg.wheelspeed_fl = v. wheelspeed_fl ;
    vmsg.wheelspeed_fr = v. wheelspeed_fr ;
    vmsg.wheelspeed_rl = v. wheelspeed_rl ;
    vmsg.wheelspeed_rr = v. wheelspeed_rr ;
    vmsg.yawrate = v. yawrate ;

    writer->write(vmsg, "/VehDyn", vmsg.header.stamp);
    }



std::cout<<i<<" / "<<allmsg<<std::endl;


}



return 1;
}