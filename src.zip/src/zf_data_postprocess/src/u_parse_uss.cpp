#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>
#include <zf_data_postprocess/parse_uuss_mindistance.hpp>

using std::placeholders::_1;
using namespace std;

string fstpath="/home/changhe/DivUCoop/parsed/uss/";

string fstopic="/UUssMinDistance";

int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllUssFile(filemap,"/home/changhe/DivUCoop/parsed/uss/");
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"uss","sqlite3"};

    writer.open(storage_options);
    add_topic(writer,"/UUssMinDistance","project_msgs/msg/UUssMinDistance");


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);

    project_msgs::msg::UUssMinDistance uss;
    uss.header.stamp=rclcpp::Time(t);
    uss.header.frame_id="base_link";
    uss.mindistance.resize(12);
    for(int i=0;i<12;i++)
    {
        uss.mindistance[i]=outvec[i];
    }

    

    writer.write(uss, "/UUssMinDistance", uss.header.stamp);

  }



// rosbag2_cpp::Reader reader;
// reader.open(imubag);
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();
//       if(bag_message->topic_name == imutopic)
//       {
//       sensor_msgs::msg::Imu extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
//     rclcpp::Serialization<sensor_msgs::msg::Imu> serialization;
//         serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);
// SaveOneImuMsg(extracted_test_msg);
//       }
    // }



  return 0;
}