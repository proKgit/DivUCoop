#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <sensor_msgs/msg/compressed_image.hpp>

#include <fstream>
#include <vector>

#include <zf_data_postprocess/parse_compressed_image.hpp>
#include "sensor_msgs/msg/image.hpp"



#define IMGBAG_SRC_PATH "/media/changhe/Data/JTcampus_around_data/notavel_valid/camera_bag"

// #define IMGBAG_SRC_PATH "/home/changhe/rosbag2_data_postprocessing/imgbag_2"

using namespace std;

int main(int argc, char * argv[])
{

// parseCompressedImgToBag("/home/changhe/rosbag2_data_postprocessing/img_bin/","imgbag_2","/my_camera_0/image_raw/compressed");

// extractCompressedImage(IMGBAG_SRC_PATH,"/my_camera_0/image_raw/compressed","/home/changhe/rosbag2_data_postprocessing/img_bin/");

//   vector<string> files;
//   vector<uint64_t> ts;
//   std::vector<std::pair<std::string,uint64_t>> filemap;
//   getAllBinFile(filemap,"/home/changhe/rosbag2_data_postprocessing/img_bin/");

// std::sort(filemap.begin(), filemap.end(), [](const std::pair<string, uint64_t>& a, const std::pair<string, uint64_t>& b) {
//     return a.second < b.second;
// });

// {
//     rosbag2_cpp::Writer writer;
//     rosbag2_storage::StorageOptions storage_options{"imgbag_2","sqlite3"};
//     // storage_options.storage_id = "sqlite3";
//     // storage_options.uri = "/home/changhe/rosbag2_data_postprocessing/my_bag";
//     writer.open(storage_options);
//     add_topic(writer,"/my_camera_0/image_raw/compressed","sensor_msgs/msg/CompressedImage");

//     for(int i=0;i<filemap.size();i++)
//     {
//       auto f=filemap[i].first;
//       auto t=filemap[i].second;
//       writeOneCompressedImg(writer,f,t,"/my_camera_0/image_raw/compressed");
//     }
//     // for(int i=0;i<files.size();i++)
//     // {
//     //   // auto f=files[i];
//     //   auto t=ts[i];
//     //   string f="/home/changhe/rosbag2_data_postprocessing/img_bin/"+to_string(t)+".bin";
//     //   std::cout<<f<<endl;
//     //   writeOneCompressedImg(writer,f,t,"/my_camera_0/image_raw/compressed");
//     // }
// }


// std::vector<uint8_t> buf;

// sensor_msgs::msg::CompressedImage testmsg;
// testmsg.header.stamp=rclcpp::Time(1673497992600671131);
// testmsg.header.frame_id="camera";
// testmsg.format="jpeg";

// readUint8FromBinFile(buf,"/media/changhe/Data/radar_odom_img_bin/img_bin/1679981699789899673.bin");
// testmsg.data=buf;

// cv::Mat tempimg = cv::imdecode(buf,1);
// cv::imshow("res",tempimg);
// cv::waitKey();

// auto buf = read_vector_from_disk("/media/changhe/Data/radar_odom_img_bin/img_bin/1679981699789899673.bin");
// cv::Mat tempimg = cv::imdecode(buf,1);

// cv::imwrite("/home/changhe/rosbag2_data_postprocessing/test.jpg",tempimg);
        // auto buf=read_vector_from_disk("/media/changhe/Data/radar_odom_img_bin/img_bin/1679981699789899673.bin");

//  cv::Mat tempimg=cv::imread("/media/changhe/Data/radar_odom_img_bin/img_bin/1679981699789899673.jpg");
//         // cv::imwrite("/home/changhe/rosbag2_data_postprocessing/img_bin/"+std::to_string(ts_temp)+".jpg",tempimg);
//    std::cout<<"READ END "<<std::endl;


//         cv::imshow("Lines",tempimg);
//         cv::waitKey(10);
//         std::cout<<"IMSHOW END "<<std::endl;
// {
//     rosbag2_cpp::Writer writer;
//     rosbag2_storage::StorageOptions storage_options{"testimgbag","sqlite3"};
//     writer.open(storage_options);
//     add_topic(writer,"/testimg","sensor_msgs/msg/CompressedImage");

//     for (int i=0;i<100;i++)
//     {
//       writer.write(testmsg, "/testimg", rclcpp::Clock().now());
//     }
//     // for(int i=0;i<100;i++)
//     // {
//     // std_msgs::msg::String msg;
//     // msg.data=to_string(i);
//     // // now we already can write the msg directly!
//     // writer.write(msg, "/helloworld", rclcpp::Clock().now());
//     // }

// }



// extractCompressedImage(IMGBAG_SRC_PATH,"/my_camera_0/image_raw/compressed","/home/changhe/rosbag2_data_postprocessing/img_bin/");




// rosbag2_cpp::Reader reader;
// reader.open(IMGBAG_SRC_PATH);
// std::vector<std::string> topics;

//     while (reader.has_next()) {

//       auto bag_message = reader.read_next();
//       bag_message->time_stamp;
//       if(bag_message->topic_name == "/my_camera_0/image_raw/compressed")
//       {
//         sensor_msgs::msg::CompressedImage extracted_test_msg;
//         rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
//         rclcpp::Serialization<sensor_msgs::msg::CompressedImage> serialization;
//         serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);

//         int64_t ts_temp=rclcpp::Time(extracted_test_msg.header.stamp).nanoseconds();
//         cout<<std::to_string( ts_temp  )<<endl;
//         cout<<extracted_test_msg.data.size()<<endl;
//         cout<<extracted_test_msg.header.stamp.nanosec<<endl;
//         cout<<extracted_test_msg.format<<endl;

//         writeUint8ToBinFile(extracted_test_msg.data,"/home/changhe/rosbag2_data_postprocessing/img_bin/"+std::to_string( ts_temp )+".bin");


//         // cv::Mat tempimg = cv::imdecode(extracted_test_msg.data,1);
//         // cv::imwrite("/home/changhe/rosbag2_data_postprocessing/img_bin/"+std::to_string( ts_temp )+".jpg",tempimg);

//         // auto buf=read_vector_from_disk("/home/changhe/rosbag2_data_postprocessing/img_bin/"+std::to_string( ts_temp )+".bin");
//         // cv::Mat tempimg = cv::imdecode(buf,1);

//         // cv::imwrite("/home/changhe/rosbag2_data_postprocessing/img_bin/"+std::to_string(ts_temp)+".jpg",tempimg);
//         // cv::imshow("Lines",tempimg);
//         // cv::waitKey();


//         // static int counter=0;
//         // if(counter++ > 10)
//         // {
//         //   break;
//         // }
//       }
//     }
        

//       }

//     }
  return 0;
}