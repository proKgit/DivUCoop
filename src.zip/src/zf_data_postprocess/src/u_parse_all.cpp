#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <zf_data_postprocess/parse_ucameraobjlist.hpp>
#include <zf_data_postprocess/parse_uparkingslot.hpp>
#include <sensor_msgs/msg/compressed_image.hpp>
#include <zf_data_postprocess/parse_uvehicle.hpp>
#include <fstream>
#include <vector>
#include <zf_data_postprocess/parse_uuss_mindistance.hpp>
#include <zf_data_postprocess/parse_compressed_image.hpp>
#include <zf_data_postprocess/parse_frgen_ros1.hpp>
#include <zf_data_postprocess/parse_odo.hpp>

#include <zf_data_postprocess/parse_vdy.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include "sensor_msgs/msg/image.hpp"
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>
#include <project_msgs/msg/vehicle_dynamics.hpp>
#include <zf_data_postprocess/parse_imu.hpp>
#include <zf_data_postprocess/parse_ufreespace.hpp>


using namespace std;

string srcBasePath="/home/changhe/DivUCoop/parsed/";


string dstBagPath = "/home/changhe/DivUCoop/bag";

long get_dir_size(const char *dir) {
    long size = 0;
    DIR *dp;
    struct dirent *ep;
    dp = opendir(dir);
    if(dp != NULL) {
        while(ep = readdir(dp)){
            if(strcmp(ep->d_name, ".") && strcmp(ep->d_name, "..")) {
                struct stat st;
                char path[1024];
                sprintf(path, "%s/%s", dir, ep->d_name);
                stat(path, &st);
                size += st.st_size;
            }
        }
        closedir(dp);
    }
    return size;
}

int main(int argc, char * argv[])
{

  std::vector<std::pair<std::string,uint64_t>> ordered_msg;

  getAllFreespaceFile(ordered_msg,srcBasePath+"fs/");

  getAllUCamObjFile(ordered_msg,srcBasePath+"obj/");

  getAllUParkingSlotFile(ordered_msg,srcBasePath+"ps/");

  getAllUssFile(ordered_msg,srcBasePath+"uss/");
  getAllUVehicleFile(ordered_msg,srcBasePath+"vdy/");

  std::sort(ordered_msg.begin(), ordered_msg.end(), [](const std::pair<string, uint64_t>& a, const std::pair<string, uint64_t>& b) {
    return a.second < b.second;
});




int allmsg=ordered_msg.size();

int bagcounter=0;
string currentbagpath=dstBagPath+"_"+to_string(bagcounter);


// std::shared_ptr<rosbag2_cpp::Writer> writer(new rosbag2_cpp::Writer());

rosbag2_cpp::Writer writer;
// rosbag2_cpp::Writer *writer;
rosbag2_storage::StorageOptions storage_options{currentbagpath,"sqlite3"};
writer.open(storage_options);

    add_topic(writer,"/USvsCamObjList","project_msgs/msg/USvsCameraObjectList");
    add_topic(writer,"/USvsParkingSlot","project_msgs/msg/USvsParkingSlotList");
    add_topic(writer,"/UUssMinDistance","project_msgs/msg/UUssMinDistance");
    add_topic(writer,"/VehDyn","project_msgs/msg/VehicleDynamics");
    add_topic(writer,"/USvsFreespace","project_msgs/msg/USvsFreespace");


for(int i=0;i<ordered_msg.size();i++)
{
  if(i % 1000 == 0)
  {
    auto si=get_dir_size(currentbagpath.c_str());
    std::cout<<"Current size is "<<si<<std::endl;
  }



    if(ordered_msg[i].first.find(".objtxt")!=std::string::npos)
    {
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);

    project_msgs::msg::USvsCameraObjectList list;
    list.header.stamp=rclcpp::Time(t);
    list.header.frame_id="base_link";
    list.objlist.resize(64);
    for(int i=0;i<64;i++)
    {
        auto& obj = list.objlist[i];
        obj.distancex = outvec[i*29 + 0];
        obj.distancey = outvec[i*29 + 1];
        obj.trackingid = outvec[i*29 + 2];
        obj.classid = outvec[i*29 + 3];
        obj.angleview = outvec[i*29 + 4];
        obj.confidence = outvec[i*29 + 5];
        obj.width = outvec[i*29 + 6];
        obj.height = outvec[i*29 + 7];
        obj.length = outvec[i*29 + 8];
        obj.yaw = outvec[i*29 + 9];
        obj.relvx = outvec[i*29 + 10];
        obj.relvy = outvec[i*29 + 11];
        obj.accelx = outvec[i*29 + 12];
        obj.accely = outvec[i*29 + 13];
        obj.motionstatus = outvec[i*29 + 14];
        obj.validstatus = outvec[i*29 + 15];

        obj.targetsource = outvec[i*29 + 16];
        obj.dimvarx = outvec[i*29 + 17];
        obj.dimvary = outvec[i*29 + 18];
        obj.disvarx = outvec[i*29 + 19];
        obj.disvary = outvec[i*29 + 20];
        obj.relvelvarx = outvec[i*29 + 21];
        obj.relvelvary = outvec[i*29 + 22];
        obj.accelvarx = outvec[i*29 + 23];
        obj.accelvary = outvec[i*29 + 24];
        obj.yawvar = outvec[i*29 + 25];
        obj.lifetime = outvec[i*29 + 26];
        obj.prelifetime = outvec[i*29 + 27];
        obj.snsrconfrim = outvec[i*29 + 28];
    }
    writer.write(list, "/USvsCamObjList", list.header.stamp);
    }


    if(ordered_msg[i].first.find(".pstxt")!=std::string::npos)
    {
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);
    project_msgs::msg::USvsParkingSlotList list;
    list.header.stamp=rclcpp::Time(t);
    list.header.frame_id="base_link";

    list.pslist.resize(16);

    for(int i=0;i<16;i++)
    {
        auto& ps =  list.pslist[i];
        ps.timestamp = outvec[37*i + 0];
        ps.frameidx = outvec[37*i + 1];
        ps.p0x = outvec[37*i + 2];
        ps.p0y = outvec[37*i + 3];
        ps.p1x = outvec[37*i + 4];
        ps.p1y = outvec[37*i + 5];
        ps.p2x = outvec[37*i + 6];
        ps.p2y = outvec[37*i + 7];
        ps.p3x = outvec[37*i + 8];
        ps.p3y = outvec[37*i + 9];
        ps.width = outvec[37*i + 10];
        ps.depth = outvec[37*i + 11];
        ps.direction = outvec[37*i + 12];
        ps.slottype = outvec[37*i + 13];

        ps.slotstatus = outvec[37*i + 14];

        ps.slotdirectiontype = outvec[37*i + 15];
        ps.slotoccupied = outvec[37*i + 16];
        ps.quality = outvec[37*i + 17];
        ps.angle = outvec[37*i + 18];
        ps.lanewidth = outvec[37*i + 19];
        ps.trackingid= outvec[37*i + 20];

        ps.serialnumber.resize(16);

        ps.serialnumber[0] = outvec[37*i + 21];
        ps.serialnumber[1] = outvec[37*i + 22];
        ps.serialnumber[2] = outvec[37*i + 23];

        ps.serialnumber[3] = outvec[37*i + 24];
        ps.serialnumber[4] = outvec[37*i + 25];
        ps.serialnumber[5] = outvec[37*i + 26];
        ps.serialnumber[6] = outvec[37*i + 27];
        ps.serialnumber[7] = outvec[37*i + 28];
        ps.serialnumber[8] = outvec[37*i + 29];
        ps.serialnumber[9] = outvec[37*i + 30];
        ps.serialnumber[10] = outvec[37*i + 31];
        ps.serialnumber[11] = outvec[37*i + 32];
        ps.serialnumber[12] = outvec[37*i + 33];
        ps.serialnumber[13] = outvec[37*i + 34];
        ps.serialnumber[14] = outvec[37*i + 35];
        ps.serialnumber[15] = outvec[37*i + 36];
    }

    writer.write(list, "/USvsParkingSlot", list.header.stamp);
    }



    if(ordered_msg[i].first.find(".usstxt")!=std::string::npos)
    {
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;
    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);

    project_msgs::msg::UUssMinDistance uss;
    uss.header.stamp=rclcpp::Time(t);
    uss.header.frame_id="base_link";
    uss.mindistance.resize(12);
    for(int i=0;i<12;i++)
    {
        uss.mindistance[i]=outvec[i];
    }
    writer.write(uss, "/UUssMinDistance", uss.header.stamp);
    }



    if(ordered_msg[i].first.find(".vdytxt")!=std::string::npos)
    {
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);
    project_msgs::msg::VehicleDynamics vdymsg;
    vdymsg.header.stamp = rclcpp::Time(t);
    vdymsg.header.frame_id = "base_link";
    vdymsg.wheelspeed_rr = outvec[0];
    vdymsg.wheelspeed_rl = outvec[1];
    vdymsg.wheelspeed_fr = outvec[2];
    vdymsg.wheelspeed_fl = outvec[3];

    vdymsg.vehspeed = outvec[12];
    //direction:
    //0 -> stationary , 1-> reverse 2-> forward
    if(outvec[6] == 1)
    {
        vdymsg.wheelspeed_rr *= -1;
        vdymsg.wheelspeed_rl *= -1;
        vdymsg.wheelspeed_fr *= -1;
        vdymsg.wheelspeed_fl *= -1;
        vdymsg.vehspeed *=-1;
    }
    vdymsg.longaccel = outvec[14];
    vdymsg.lataccel = outvec[16];
    vdymsg.yawrate = outvec[19];
    vdymsg.timestamp = outvec[20];
    writer.write(vdymsg, "/VehDyn", vdymsg.header.stamp);
    }



    if(ordered_msg[i].first.find(".fstxt")!=std::string::npos)
    {
    auto f = ordered_msg[i].first;
    auto t=ordered_msg[i].second;


    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);

project_msgs::msg::USvsFreespace fs;

fs.header.stamp=rclcpp::Time(t);
fs.header.frame_id="base_link";
fs.pointnum = outvec[0];
fs.closedcontour=outvec[1];
fs.vehiclepoints.resize(400);
for(int i=0;i<400;i++)
{
    fs.vehiclepoints[i].x = outvec[2+ i*9+0];
    fs.vehiclepoints[i].y = outvec[2+ i*9+1];
    fs.vehiclepoints[i].classtype = outvec[2+ i*9+2];
    fs.vehiclepoints[i].edge = outvec[2+ i*9+3];
    fs.vehiclepoints[i].id = outvec[2+ i*9+4];
    fs.vehiclepoints[i].vehiclex = outvec[2+ i*9+5];
    fs.vehiclepoints[i].vehicley = outvec[2+ i*9+6];
    fs.vehiclepoints[i].vehicleheading = outvec[2+ i*9+7];
    fs.vehiclepoints[i].fspointsource = outvec[2+ i*9+8];
}
fs.colortype=outvec[outvec.size() -2];
fs.classtype=outvec[outvec.size() -1];

std::cout<<fs.pointnum<<std::endl;

    writer.write(fs, "/USvsFreespace", fs.header.stamp);
    }



std::cout<<i<<" / "<<allmsg<<std::endl;


}



return 1;
}