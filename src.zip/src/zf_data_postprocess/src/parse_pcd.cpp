#include <zf_data_postprocess/parse_pcd.hpp>

using std::placeholders::_1;
using namespace std;

int main(int argc, char * argv[])
{



    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"pcdbag","sqlite3"};

    writer.open(storage_options);
    add_topic(writer,"/pcd_test","sensor_msgs/msg/PointCloud2");

  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllPcdFile(filemap,"/media/changhe/Data/ConvertedPclData/128/");

  for(int i=0;i<60*10;i++)
  {
    auto f=filemap[i].first;
    auto t=filemap[i].second;

writeOnePcd(writer,f,t,"test_pcd","pandar128");

// pcl::PointCloud<pcl::PointXYZI> cloud;
// if (pcl::io::loadPCDFile<pcl::PointXYZI> (f, cloud) == -1) //* load the file
// {
//   PCL_ERROR ("Couldn't read file test_pcd.pcd \n");
//   return (-1);
// }
//       sensor_msgs::msg::PointCloud2 msg;
//       pcl::toROSMsg(cloud, msg);
//       msg.header.stamp=rclcpp::Time(t);
//       msg.header.frame_id="pandar128";
//       cout<<t<<endl;
//     // now we already can write the msg directly!
//     writer.write(msg, "/pcd_test", rclcpp::Time(t));





  }





// {
//     rosbag2_cpp::Writer writer;
//     rosbag2_storage::StorageOptions storage_options{"pcdbag","sqlite3"};

//     writer.open(storage_options);
//     add_topic(writer,"/pcd_test","sensor_msgs/msg/PointCloud2");

// pcl::PointCloud<pcl::PointXYZI> cloud;
// if (pcl::io::loadPCDFile<pcl::PointXYZI> ("/media/changhe/Data/ConvertedPclData/128/1673497980548816204.pcd", cloud) == -1) //* load the file
// {
//   PCL_ERROR ("Couldn't read file test_pcd.pcd \n");
//   return (-1);
// }
//       sensor_msgs::msg::PointCloud2 msg;
//           pcl::toROSMsg(cloud, msg);
//       msg.header.stamp=rclcpp::Clock().now();
//       msg.header.frame_id="pandar128";

//       cout<<msg.data.size()<<endl;

//     // now we already can write the msg directly!
//     writer.write(msg, "/pcd_test", rclcpp::Clock().now());
// }

// rosbag2_cpp::Reader reader;
// reader.open("mybag");
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();

//       topics.push_back(bag_message->topic_name);

//       std::cout<<bag_message->topic_name<<std::endl;

//       std_msgs::msg::String extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);

//   rclcpp::Serialization<std_msgs::msg::String> serialization;

//       serialization.deserialize_message(
//         &extracted_serialized_msg, &extracted_test_msg);
//     std::cout<<extracted_test_msg.data<<std::endl;
//     }
  return 0;
}