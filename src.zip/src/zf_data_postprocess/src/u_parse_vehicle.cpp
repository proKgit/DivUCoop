#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>
#include <zf_data_postprocess/parse_uvehicle.hpp>

using std::placeholders::_1;
using namespace std;

string fstpath="/home/changhe/DivUCoop/parsed/vdy/";

string fstopic="/VehDyn";

int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllUVehicleFile(filemap,"/home/changhe/DivUCoop/parsed/vdy/");
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"vdy","sqlite3"};

    writer.open(storage_options);
    add_topic(writer,"/VehDyn","project_msgs/msg/VehicleDynamics");


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);
    
    project_msgs::msg::VehicleDynamics vdymsg;
    vdymsg.header.stamp = rclcpp::Time(t);
    vdymsg.header.frame_id = "base_link";

    vdymsg.wheelspeed_rr = outvec[0];
    vdymsg.wheelspeed_rl = outvec[1];
    vdymsg.wheelspeed_fr = outvec[2];
    vdymsg.wheelspeed_fl = outvec[3];

    vdymsg.vehspeed = outvec[12];

    //direction:
    //0 -> stationary , 1-> reverse 2-> forward

    if(outvec[6] == 1)
    {
        vdymsg.wheelspeed_rr *= -1;
        vdymsg.wheelspeed_rl *= -1;
        vdymsg.wheelspeed_fr *= -1;
        vdymsg.wheelspeed_fl *= -1;
        vdymsg.vehspeed *=-1;
    }

    // vdymsg.wheelpulse_rr = outvec[4];
    // vdymsg.wheelpulse_rl = outvec[5];
    // vdymsg.wheelpulse_fr = outvec[6];
    // vdymsg.wheelpulse_fl = outvec[7];

//vehpar
    // vdymsg.wheelspeed_rr = outvec[8];
    // vdymsg.wheelspeed_rr = outvec[9];
    // vdymsg.wheelspeed_rr = outvec[10];
    // vdymsg.wheelspeed_rr = outvec[11];


    // vdymsg.vehspeed = outvec[13];

    vdymsg.longaccel = outvec[14];
    // vdymsg.vehspeed = outvec[15];
    vdymsg.lataccel = outvec[16];
    // vdymsg.vehspeed = outvec[17];

    vdymsg.yawrate = outvec[19];

    vdymsg.timestamp = outvec[20];

    writer.write(vdymsg, "/VehDyn", vdymsg.header.stamp);

  }



// rosbag2_cpp::Reader reader;
// reader.open(imubag);
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();
//       if(bag_message->topic_name == imutopic)
//       {
//       sensor_msgs::msg::Imu extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
//     rclcpp::Serialization<sensor_msgs::msg::Imu> serialization;
//         serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);
// SaveOneImuMsg(extracted_test_msg);
//       }
    // }



  return 0;
}