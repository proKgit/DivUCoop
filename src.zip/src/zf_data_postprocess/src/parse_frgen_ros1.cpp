
#include <zf_data_postprocess/parse_frgen_ros1.hpp>

using namespace std;


int main(int argc, char * argv[])
{



    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"frgen_bag","sqlite3"};
    // storage_options.storage_id = "sqlite3";
    // storage_options.uri = "/home/changhe/rosbag2_data_postprocessing/my_bag";
    writer.open(storage_options);
    add_topic(writer,"/frgen","project_msgs/msg/RadarScanExtended");

  FrgenDetectionList_t in_list;

  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllFrgenFile(filemap,"/home/changhe/rosbag_parse_frgen/");
  for(int i=0;i<filemap.size();i++)
  {

    project_msgs::msg::RadarScanExtended scan;
    std::ifstream in(filemap[i].first, std::ios::binary);
    in.read(reinterpret_cast<char*>(&in_list), sizeof(in_list));
    in.close();

    scan.header.frame_id="frgen";
    scan.header.stamp=rclcpp::Time(in_list.ts);
    scan.targets.resize(in_list.numofdetection);

    for(int i=0;i<scan.targets.size();i++)
    {
      scan.targets[i].azimuth=in_list.list[i].azimuth;
      scan.targets[i].detectionconfidence  =  in_list.list[i].detectionconfidence;
      scan.targets[i].elevation  =  in_list.list[i].elevation;
      scan.targets[i].mean_square_error_azimuth  =  in_list.list[i].mean_square_error_azimuth;
      scan.targets[i].mean_square_error_elevation  =  in_list.list[i].mean_square_error_elevation;
      scan.targets[i].mean_square_error_range  =  in_list.list[i].mean_square_error_range;
      scan.targets[i].mean_square_error_subarray2nd_best  =  in_list.list[i].mean_square_error_subarray2nd_best;
      scan.targets[i].mean_square_error_subarray  =  in_list.list[i].mean_square_error_subarray;
      scan.targets[i].mean_square_error_velocity  =  in_list.list[i].mean_square_error_velocity;
      scan.targets[i].power  =  in_list.list[i].power;
      scan.targets[i].range  =  in_list.list[i].range;
      scan.targets[i].rcs  =  in_list.list[i].rcs;
      scan.targets[i].snr  =  in_list.list[i].snr;
      scan.targets[i].std_dev_azimuthangle  =  in_list.list[i].std_dev_azimuthAngle;
      scan.targets[i] .std_dev_elevationangle =  in_list.list[i].std_dev_elevationAngle;
      scan.targets[i].std_dev_range  =  in_list.list[i].std_dev_range;
      scan.targets[i] .std_dev_rcs =  in_list.list[i].std_dev_rcs;
      scan.targets[i].std_dev_velocity  =  in_list.list[i].std_dev_velocity;
      scan.targets[i].velocity  =  in_list.list[i].velocity;
    }
    scan.umabiguos_int_azimuth=in_list.umabiguos_int_azimuth;
    scan.umabiguos_int_elevation=in_list.umabiguos_int_elevation;
    scan.umabiguos_int_range=in_list.umabiguos_int_range;
    scan.umabiguos_int_velocity=in_list.umabiguos_int_velocity;

writer.write(scan, "/frgen", scan.header.stamp);
  }

  return 0;
}