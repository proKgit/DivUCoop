#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>
#include <zf_data_postprocess/parse_ucameraobjlist.hpp>

using std::placeholders::_1;
using namespace std;

string fstpath="/home/changhe/DivUCoop/parsed/obj/";

string fstopic="/USvsCamObjList";

int main(int argc, char * argv[])
{
  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllUCamObjFile(filemap,"/home/changhe/DivUCoop/parsed/obj/");
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{"cam","sqlite3"};

    writer.open(storage_options);
    add_topic(writer,"/USvsCamObjList","project_msgs/msg/USvsCameraObjectList");


  for(int i=0;i<filemap.size();i++)
  {
    auto f = filemap[i].first;
    auto t=filemap[i].second;

    std::vector<double> outvec;
    parseOneLineTxtIntoVector(f,outvec);

    project_msgs::msg::USvsCameraObjectList list;
    list.header.stamp=rclcpp::Time(t);
    list.header.frame_id="base_link";
    list.objlist.resize(64);
    for(int i=0;i<64;i++)
    {
        auto& obj = list.objlist[i];
        obj.distancex = outvec[i*29 + 0];
        obj.distancey = outvec[i*29 + 1];
        obj.trackingid = outvec[i*29 + 2];
        obj.classid = outvec[i*29 + 3];
        obj.angleview = outvec[i*29 + 4];
        obj.confidence = outvec[i*29 + 5];
        obj.width = outvec[i*29 + 6];
        obj.height = outvec[i*29 + 7];
        obj.length = outvec[i*29 + 8];
        obj.yaw = outvec[i*29 + 9];
        obj.relvx = outvec[i*29 + 10];
        obj.relvy = outvec[i*29 + 11];
        obj.accelx = outvec[i*29 + 12];
        obj.accely = outvec[i*29 + 13];
        obj.motionstatus = outvec[i*29 + 14];
        obj.validstatus = outvec[i*29 + 15];

        obj.targetsource = outvec[i*29 + 16];
        obj.dimvarx = outvec[i*29 + 17];
        obj.dimvary = outvec[i*29 + 18];
        obj.disvarx = outvec[i*29 + 19];
        obj.disvary = outvec[i*29 + 20];
        obj.relvelvarx = outvec[i*29 + 21];
        obj.relvelvary = outvec[i*29 + 22];
        obj.accelvarx = outvec[i*29 + 23];
        obj.accelvary = outvec[i*29 + 24];
        obj.yawvar = outvec[i*29 + 25];
        obj.lifetime = outvec[i*29 + 26];
        obj.prelifetime = outvec[i*29 + 27];
        obj.snsrconfrim = outvec[i*29 + 28];
    }

    writer.write(list, "/USvsCamObjList", list.header.stamp);

  }



// rosbag2_cpp::Reader reader;
// reader.open(imubag);
// std::vector<std::string> topics;
//     while (reader.has_next()) {
//       auto bag_message = reader.read_next();
//       if(bag_message->topic_name == imutopic)
//       {
//       sensor_msgs::msg::Imu extracted_test_msg;
//       rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
//     rclcpp::Serialization<sensor_msgs::msg::Imu> serialization;
//         serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);
// SaveOneImuMsg(extracted_test_msg);
//       }
    // }



  return 0;
}