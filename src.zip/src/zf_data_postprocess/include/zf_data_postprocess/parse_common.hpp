#pragma once
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <sensor_msgs/msg/compressed_image.hpp>

#include <fstream>
#include <vector>

#include <iostream>
#include <vector>
#include <dirent.h>
#include <string>

#include "sensor_msgs/msg/image.hpp"
#include "cv_bridge/cv_bridge.h"


void add_topic(rosbag2_cpp::Writer& w,std::string name,std::string type,std::string serialization_frmt = "cdr")
{
    rosbag2_storage::TopicMetadata tm;
    tm.name = name;
    tm.type = type;
    tm.serialization_format = serialization_frmt;
    w.create_topic(tm);
}


void parseOneLineTxtIntoVector(std::string filepath,std::vector<double> &numbers)
{
        std::ifstream inputFile(filepath); // Replace "input.txt" with the actual file path
        numbers.clear();

    if (inputFile.is_open()) {
        std::string line;
        std::getline(inputFile, line);

        std::istringstream iss(line);
        double number;

        while (iss >> number) {
            numbers.push_back(number);
        }

        inputFile.close();
    } else {
        std::cout << "Unable to open the file." << std::endl;
        return ;
    }
}