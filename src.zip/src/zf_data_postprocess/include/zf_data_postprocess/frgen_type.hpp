#pragma once
#include <string.h>
#include <math.h>
#include <stdint.h>
typedef float float32;
typedef char uint8;
typedef uint16_t uint16;

typedef struct
{
    float range;
    float azimuth;
    float elevation;
    float velocity;
    float snr;
    float power;
    float rcs;
    float detectionconfidence;
    float mean_square_error_range;
    float mean_square_error_velocity;
    float mean_square_error_azimuth;
    float mean_square_error_elevation;
    float mean_square_error_subarray;
    float mean_square_error_subarray2nd_best;
    float std_dev_range;
    float std_dev_velocity;
    float std_dev_azimuthAngle;
    float std_dev_elevationAngle;
    float std_dev_rcs;
}FrgenDetection_t;



typedef struct
{
    uint64_t ts;
    int numofdetection;
    FrgenDetection_t list[2000];
    float umabiguos_int_range;
    float umabiguos_int_velocity;
    float umabiguos_int_azimuth;
    float umabiguos_int_elevation;
} FrgenDetectionList_t;



typedef struct
{
    uint64_t ts;
    float vehspeed;
    float longaccel;
    float lataccel;
    float yawrate;
    float steeringwheelangle;
    float frontwheelangle;
    uint8_t wheelpulse_fl;
    uint8_t wheelpulse_fr;
    uint8_t wheelpulse_rl;
    uint8_t wheelpulse_rr;
    float wheelspeed_fl;
    float wheelspeed_fr;
    float wheelspeed_rl;
    float wheelspeed_rr;
}FrgenVehDyn_t;


typedef struct
{
    uint64_t ts;
    double x;
    double y;
    double z;

    double qx;
    double qy;
    double qz;
    double qw;

    double vx;
    double vy;
    double vz;
    double wx;
    double wy;
    double wz;

    double variance[9];
}FrgenOdom_t;




typedef struct FSPP_CameraFreespacePoints_t_Tag
{
    float32 X;
    float32 Y;
    uint8 ClassType;
    uint8 Edge;
    uint16 Id;
    float32 VehicleX;
    float32 VehicleY;
    float32 VehicleHeading;
    uint8 FSPointSource;
}FSPP_CameraFreespacePoints_t;

typedef struct FSPP_CameraFreespaceType_t_Tag
{
    uint16 PointNum;
    uint8 ClosedContour;
    FSPP_CameraFreespacePoints_t VehiclePoints[400];
    uint8 ColorType;
    uint8 ClassType;
}FSPP_CameraFreespaceType_t;
