#pragma once

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <sensor_msgs/msg/compressed_image.hpp>

#include <fstream>
#include <vector>

#include <iostream>
#include <vector>
#include <dirent.h>
#include <string>

#include <sensor_msgs/msg/point_cloud2.hpp>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>

#include <zf_data_postprocess/parse_common.hpp>
#include <pcl_conversions/pcl_conversions.h>



void getAllPcdFile(std::vector<std::pair<std::string,uint64_t>> &outmap,std::string folder)
{
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir (folder.c_str())) != NULL) {
    while ((ent = readdir (dir)) != NULL) {
        std::string fileName = ent->d_name;
        if(fileName.find(".pcd")!=std::string::npos){
            std::pair<std::string,uint64_t> newp { folder+fileName, (uint64_t) std::stod(fileName.substr(0, fileName.find("."))) };
            outmap.push_back(newp);
        }
    }
    closedir (dir);
    }
}


void writeOnePcd(rosbag2_cpp::Writer& w,std::string fullpath,uint64_t msg_ts,std::string topic, std::string frame_id)
{
pcl::PointCloud<pcl::PointXYZI> cloud;

if (pcl::io::loadPCDFile<pcl::PointXYZI> (fullpath, cloud) == -1) //* load the file
{
  PCL_ERROR ("Couldn't read file test_pcd.pcd \n");
  return;
}
      sensor_msgs::msg::PointCloud2 msg;
      pcl::toROSMsg(cloud, msg);
      msg.header.stamp=rclcpp::Time(msg_ts);
      msg.header.frame_id=frame_id;
      std::cout<<msg_ts<<std::endl;
    // now we already can write the msg directly!
    w.write(msg, topic, rclcpp::Time(msg_ts));
}