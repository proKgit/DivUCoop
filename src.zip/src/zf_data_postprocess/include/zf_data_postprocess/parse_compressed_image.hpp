#pragma once
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <sensor_msgs/msg/compressed_image.hpp>

#include <fstream>
#include <vector>

#include <iostream>
#include <vector>
#include <dirent.h>
#include <string>

#include "sensor_msgs/msg/image.hpp"
#include "cv_bridge/cv_bridge.h"

#include "zf_data_postprocess/parse_common.hpp"


inline std::vector<uint8_t> read_vector_from_disk(std::string file_path)
    {
        std::ifstream instream(file_path, std::ios::in | std::ios::binary);
        std::vector<uint8_t> data((std::istreambuf_iterator<char>(instream)), std::istreambuf_iterator<char>());
        return data;
}


void writeUint8ToBinFile(std::vector<uint8_t>& data, const std::string& fileName)
{
    std::ofstream outfile(fileName, std::ios::binary);
    if (outfile.is_open()) {
        outfile.write(reinterpret_cast<char*>(data.data()), data.size());
        outfile.close();
    }
}

void readUint8FromBinFile(std::vector<uint8_t>& data, const std::string& fileName)
{

    std::cout<<fileName<<", "<<data.size()<<std::endl;
    std::ifstream binary_file(fileName, std::ios::binary  | std::ios::ate);

    // Get the size of the file
    // binary_file.seekg(0, binary_file.end);
    int size = binary_file.tellg();
    // binary_file.seekg(0, binary_file.beg);


    std::cout << "filesze" << size << std::endl;

    data.resize(size);
    binary_file.read(reinterpret_cast<char*>(&data[0]), size);

    std::cout << "Read " << size << " bytes from the binary file" <<", "<<data.size()<<std::endl;
    binary_file.close();
}


void getAllBinFile(std::vector<std::pair<std::string,uint64_t>> &outmap,std::string folder)
{
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir (folder.c_str())) != NULL) {
    while ((ent = readdir (dir)) != NULL) {
        std::string fileName = ent->d_name;
        if(fileName.find(".bin")!=std::string::npos){
            std::pair<std::string,uint64_t> newp { folder+fileName, (uint64_t) std::stod(fileName.substr(0, fileName.find("."))) };
            outmap.push_back(newp);
        }
    }
    closedir (dir);
    }
}


void compressedImgToCvMat(sensor_msgs::msg::CompressedImage & msg,cv::Mat outCvMat)
{
  outCvMat = cv::imdecode(msg.data,1);
}



//For the moment we use msg ts as sim ts 
void writeOneCompressedImg(rosbag2_cpp::Writer& w,std::string binfile,uint64_t msg_ts,std::string topic)
{
auto buf = read_vector_from_disk(binfile);
  sensor_msgs::msg::CompressedImage::SharedPtr msg = std::make_shared<sensor_msgs::msg::CompressedImage>();

  msg->format="jpeg";
  msg->data.resize(buf.size());
  msg->header.stamp=rclcpp::Time(msg_ts);
  memcpy(msg->data.data(),buf.data(),buf.size());

    w.write(*msg,topic,rclcpp::Time(msg_ts));
    std::cout<<std::to_string(msg_ts)<<", "<<msg->data.size()<<std::endl;
}


void extractCompressedImage(std::string IMGBAG_SRC_PATH,std::string targetTopicName,std::string dstPathEndWithSlash)
{
rosbag2_cpp::Reader reader;
reader.open(IMGBAG_SRC_PATH);
std::vector<std::string> topics;

    while (reader.has_next()) {

      auto bag_message = reader.read_next();
      bag_message->time_stamp;
      if(bag_message->topic_name == targetTopicName)
      {
        sensor_msgs::msg::CompressedImage extracted_test_msg;
        rclcpp::SerializedMessage extracted_serialized_msg(*bag_message->serialized_data);
        rclcpp::Serialization<sensor_msgs::msg::CompressedImage> serialization;
        serialization.deserialize_message(&extracted_serialized_msg, &extracted_test_msg);
        int64_t ts_temp=rclcpp::Time(extracted_test_msg.header.stamp).nanoseconds();
        std::cout<<std::to_string( ts_temp  )<<std::endl;
        writeUint8ToBinFile(extracted_test_msg.data,dstPathEndWithSlash+std::to_string( ts_temp )+".bin");
      }
    }
}


void parseCompressedImgToBag(std::string srcImgPathEndWithSlash,std::string dstBagName,std::string imgTopicName)
{
    using namespace std;

  vector<string> files;
  vector<uint64_t> ts;
  std::vector<std::pair<std::string,uint64_t>> filemap;
  getAllBinFile(filemap,srcImgPathEndWithSlash);

std::sort(filemap.begin(), filemap.end(), [](const std::pair<string, uint64_t>& a, const std::pair<string, uint64_t>& b) {
    return a.second < b.second;
});

{
    rosbag2_cpp::Writer writer;
    rosbag2_storage::StorageOptions storage_options{dstBagName,"sqlite3"};
    // storage_options.storage_id = "sqlite3";
    // storage_options.uri = "/home/changhe/rosbag2_data_postprocessing/my_bag";
    writer.open(storage_options);

    add_topic(writer,imgTopicName,"sensor_msgs/msg/CompressedImage");

    for(int i=0;i<filemap.size();i++)
    {
      auto f=filemap[i].first;
      auto t=filemap[i].second;
      writeOneCompressedImg(writer,f,t,imgTopicName);
    }
}
}