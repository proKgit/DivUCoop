#pragma once
#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>

#include <rosbag2_cpp/writer.hpp>
#include <rosbag2_cpp/reader.hpp>

#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>

#include <sensor_msgs/msg/compressed_image.hpp>

#include <fstream>
#include <vector>

#include <iostream>
#include <vector>
#include <dirent.h>
#include <string>

#include "sensor_msgs/msg/image.hpp"
#include "cv_bridge/cv_bridge.h"

#include "zf_data_postprocess/parse_common.hpp"
#include <project_msgs/msg/vehicle_dynamics.hpp>
void getAllUVehicleFile(std::vector<std::pair<std::string,uint64_t>> &outmap,std::string folder)
{
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir (folder.c_str())) != NULL) {
    while ((ent = readdir (dir)) != NULL) {
        std::string fileName = ent->d_name;
        if(fileName.find(".vdytxt")!=std::string::npos){
            std::pair<std::string,uint64_t> newp { folder+fileName, (uint64_t) std::stod(fileName.substr(0, fileName.find("."))) };
            outmap.push_back(newp);
        }
    }
    closedir (dir);
    }
}