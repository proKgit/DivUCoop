from rclpy.node import Node
from rclpy.serialization import serialize_message
from geometry_msgs.msg import Twist
import rosbag2_py
import os
import shutil
import time
writer=rosbag2_py.SequentialWriter()
storage_options=rosbag2_py.StorageOptions(uri="mybagpy",storage_id="sqlite3")
converter_options=rosbag2_py.ConverterOptions("","")

if os.path.exists("mybagpy"):
    shutil.rmtree("mybagpy")


writer.open(storage_options,converter_options)

topic_info=rosbag2_py.TopicMetadata(name='/helloworld',type='geometry_msgs/msg/Twist',serialization_format='cdr')
writer.create_topic(topic_info)


for i in range(0,10):
    msg=Twist()
    msg.angular.x=(float)(i)
    writer.write('/helloworld',serialize_message(msg),time.time_ns())
    



